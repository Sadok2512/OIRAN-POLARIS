"""判定每個 IP 端點扮演哪個網元角色。

**全部是確定性規則，沒有模型參與**（Rule 5：程式能答的就程式答）。
判定不出來時一律退回顯示 IP —— **不猜**。一個標錯網元名稱的時序圖
比一個標著 IP 的更糟：後者只是不方便，前者會讓人得出錯誤結論。

判定階梯由強到弱，先命中者為準：

1. **協定角色訊息**：只有 gNB 會送 NGSetupRequest / InitialUEMessage；
   只有 SMF 會送 PFCP Session Establishment Request。這是最強的證據。
2. **標準埠**：N2（NGAP）的 AMF 側固定聽 38412（TS 38.412）。
   PFCP 的 8805 **不算** —— 那個埠 N4 兩端都在聽，判不出誰是誰。
3. **SBI 路徑前綴**：`:path` 的第一段就是服務名，而服務名對應 NF 型別
   （TS 29.5xx 的命名慣例）。`User-Agent` 則帶發送端的 NF 型別（TS 29.500）。
4. 都沒命中 → 留 None，畫圖時顯示 IP。
"""

from __future__ import annotations

from collections import defaultdict

from telcoladder.model import NF_ROLE_HINTS_KEY, Endpoint, Message

#: N2 介面上 AMF 固定監聽的 SCTP 埠（TS 38.412）。
NGAP_PORT = 38412
#: N4 介面的 PFCP 埠（TS 29.244）。**兩端共用**，所以它不能用來判角色 ——
#: 理由見下方 `resolve_roles` 裡的說明。留著是因為它仍是「這是不是 PFCP」
#: 的事實依據。
PFCP_PORT = 8805

#: SBI 服務名 → 提供該服務的網元（TS 29.5xx）。
#: 這是規範定死的命名慣例，不是猜測。
SBI_SERVICE_TO_NF: dict[str, str] = {
    "namf-comm": "AMF",
    "namf-evts": "AMF",
    "namf-mt": "AMF",
    "namf-loc": "AMF",
    "nsmf-pdusession": "SMF",
    "nsmf-event-exposure": "SMF",
    "nudm-sdm": "UDM",
    "nudm-uecm": "UDM",
    "nudm-ueau": "UDM",
    "nudm-ee": "UDM",
    "nausf-auth": "AUSF",
    "nausf-sorprotection": "AUSF",
    "npcf-am-policy-control": "PCF",
    "npcf-smpolicycontrol": "PCF",
    "npcf-policyauthorization": "PCF",
    "nbsf-management": "BSF",
    "nnrf-nfm": "NRF",
    "nnrf-disc": "NRF",
    "nudr-dr": "UDR",
    "nnssf-nsselection": "NSSF",
    "nsmsf-sms": "SMSF",
    "nchf-convergedcharging": "CHF",
    "nnef-eventexposure": "NEF",
}

#: S1-MME 介面上 MME 固定監聽的 SCTP 埠（TS 36.412）。
S1AP_PORT = 36412

#: S1AP 的角色階梯：**程序碼 → (發起方, 回應方)**（TS 36.413）。
#:
#: 鍵是程序碼而不是訊息名，理由與 Diameter 那張表相同：名字是顯示字串，
#: 而**這裡最容易錯的正是名字看起來很像的兩個不同程序** ——
#: `UEContextReleaseRequest`（18，eNB 發起的請求）與
#: `UEContextReleaseCommand`（23，MME 下的令）是兩回事，
#: 而 `UEContextReleaseComplete` 回的是後者。第一版用「去掉後綴再加 Request」
#: 猜，結果把 Complete 配到了 18，兩端投出互相矛盾的票 ——
#: 症狀是**整張圖的網元全部退回顯示 IP**（`vote()` 遇到衝突就放棄，
#: 那是刻意的：寧可不說，也不要說錯）。
#:
#: **回話不必另外列** —— 回應走的是相反方向，所以查到之後對調即可。
#: 只收方向沒有疑義的那幾個；不在表上的一律不投票。
_S1AP_ROLES: dict[int, tuple[str, str]] = {
    9: ("MME", "eNB"),    # InitialContextSetup
    10: ("MME", "eNB"),   # Paging
    11: ("MME", "eNB"),   # downlinkNASTransport
    12: ("eNB", "MME"),   # initialUEMessage
    13: ("eNB", "MME"),   # uplinkNASTransport
    17: ("eNB", "MME"),   # S1Setup
    18: ("eNB", "MME"),   # UEContextReleaseRequest
    23: ("MME", "eNB"),   # UEContextRelease（Command 是 MME 下的令）
}

#: 只有 gNB 會主動發起的 NGAP 程序。收到方必為 AMF。
_GNB_INITIATED = {"NGSetup", "InitialUEMessage", "RANConfigurationUpdate", "UERadioCapabilityInfoIndication"}
#: 只有 AMF 會主動發起的 NGAP 程序。
_AMF_INITIATED = {"AMFConfigurationUpdate", "AMFStatusIndication", "Paging", "InitialContextSetup", "DownlinkNASTransport"}

#: NAS 在時序圖上要畫成 UE ↔ AMF。gNB 只是透明轉送者，
#: 把 NAS 畫在 gNB↔AMF 那一段是照封包畫，而不是照協定語意畫。
UE_ROLE = "UE"

#: 轉送者的角色名稱，依「揭露它的那個協定」決定。
#: Diameter adapter 落地時在這裡加 `"diameter": "DRA"` —— 判定邏輯不必動。
RELAY_ROLE_BY_PROTOCOL: dict[str, str] = {
    "sbi": "SCP",
    "diameter": "DRA",
}


def find_relays(messages: list[Message]) -> dict[str, str]:
    """找出轉送者：**收到一則指名別人的訊息的那一端**。

    判準只有一條，而且是協定中立的 —— adapter 在 `detail["relay-target"]`
    如實填上「這則訊息說它要去哪裡」，若那個目標不是線路上的收件者，
    收件者就是個轉送者。

    這條規則同時吃得下三個東西：

    * 5G 的 SCP —— `3gpp-Sbi-Target-apiRoot`（間接通訊）
    * Diameter 的 DRA / SLF —— `Destination-Host`
    * IMS 的 SIP proxy —— `Route`

    **為什麼不是特判 SCP**：在任何有轉送者的拓撲裡，線路上的對端都不是
    邏輯上的對端。把它寫成「SCP 的規則」，等 Diameter 進來時就得再寫一次，
    而那正是外掛契約要消滅的東西。

    同一個 IP 被兩個協定判成不同種轉送者時**不標** —— 比照 `resolve_roles`
    的哲學：證據矛盾時標錯比不標更糟。
    """
    candidates: dict[str, set[str]] = defaultdict(set)
    for msg in messages:
        role = RELAY_ROLE_BY_PROTOCOL.get(msg.protocol)
        if not role:
            continue

        # ── 證據 A：訊息指名的收件者不是線路上的對端（`relay-target`）──
        target = msg.detail.get("relay-target")
        if target and target != msg.dst.ip:
            # 目標就是收件者本人 → 直接通訊。少了這個判斷會把真正的網元標成 SCP。
            candidates[msg.dst.ip].add(role)

        # ── 證據 B：訊息自己說它被轉送過（`relay-record`）──
        #
        # **這一條是正面證據，而且指的是「發送者」不是「收件者」。**
        # RFC 6733 §6.7.1：relay/proxy 轉送請求時必須附上一筆 Route-Record。
        # 所以帶著 Route-Record 的訊息，**送出它的那一端就是中繼**。
        #
        # 為什麼需要它 —— 證據 A 在真實的 DRA 上會靜默失效：代理通常
        # **保留原始的 Origin-Host**，於是主機名同時對到端點與 DRA 兩個位址，
        # 「指名的收件者」看起來就在線路的另一端。實測 fixture 上證據 A
        # 找到 0 個中繼，而那份檔裡確實有一台。
        if msg.detail.get("relay-record"):
            candidates[msg.src.ip].add(role)

    return {ip: next(iter(roles)) for ip, roles in candidates.items() if len(roles) == 1}


def _diameter_vote(msg: Message, vote, src_ip: str, dst_ip: str) -> None:
    """Diameter 訊息的角色投票。

    **Answer 的方向與 Request 相反** —— 與上面 NGAP 那段是同一個坑：
    少了這一步，`3GPP-Update-Location Answer`（HSS 回的）會被判成 MME 發送，
    與 Request 的票互相矛盾，結果是兩端都因衝突而放棄判定，圖上全變成 IP。
    """
    application = msg.detail.get("application-id")
    if application is None:
        return
    code = msg.detail.get("command-code")
    if code is None:
        return
    roles = DIAMETER_ROLES.get((int(application), int(code)))
    if roles is None:
        return
    initiator_role, responder_role = roles
    is_answer = msg.label.endswith(" Answer")
    initiator = dst_ip if is_answer else src_ip
    responder = src_ip if is_answer else dst_ip
    vote(initiator, initiator_role)
    vote(responder, responder_role)


def _endpoint_key(endpoint: Endpoint) -> str:
    return endpoint.ip


def resolve_roles(messages: list[Message]) -> dict[str, str]:
    """掃過所有訊息，判定每個 IP 的網元角色。

    回傳 IP → 角色名稱。判不出來的 IP 不會出現在結果裡。

    **分兩趟，順序有語意。** 先找出轉送者（`find_relays`），再跑判定階梯 ——
    因為階梯上的證據對轉送者是無效的，而不知道誰是轉送者就分不出哪些票被
    污染了。實測 SCP 的例子：打向它的請求，服務名描述的是**最終目標**；
    它轉送出來的請求，User-Agent 描述的是**原始發送端**。兩者都不是它自己，
    而它會因此同時收到五種 NF 的票、全部互相抵銷。
    """
    relays = find_relays(messages)
    votes: dict[str, set[str]] = defaultdict(set)

    def vote(ip: str, role: str) -> None:
        """記一票。**落在轉送者身上的一律丟掉。**

        轉送者的角色已由第一趟決定，而階梯上的每一條規則都在推論
        「這個位址扮演哪個網元」—— 對一個只是把訊息傳下去的中間人來說，
        那個推論從前提就不成立。
        """
        if ip in relays:
            return
        votes[ip].add(role)

    for msg in messages:
        src_ip, dst_ip = _endpoint_key(msg.src), _endpoint_key(msg.dst)

        # ── 階梯 1：只有某一方會發起的程序 ──
        if msg.protocol == "ngap":
            base = msg.label
            # Response / Failure 是**回話**，方向與發起訊息相反。
            # 少了這一步，InitialContextSetupResponse（gNB 回的）會被判成
            # AMF 發送，與 InitialContextSetup 的票互相矛盾，結果是兩端
            # 都因衝突而放棄判定 —— 圖上全變成 IP。
            is_reply = False
            for suffix in ("Response", "Failure"):
                if base.endswith(suffix):
                    base = base.removesuffix(suffix)
                    is_reply = True
                    break

            initiator = dst_ip if is_reply else src_ip
            responder = src_ip if is_reply else dst_ip
            if base in _GNB_INITIATED:
                vote(initiator, "gNB")
                vote(responder, "AMF")
            elif base in _AMF_INITIATED:
                vote(initiator, "AMF")
                vote(responder, "gNB")

        # ── 線路上直接說了誰是誰 ──
        #
        # **這一段不認得任何 adapter。** 有些協定把網元角色寫在訊息內容裡
        # （GTPv2-C 的 F-TEID IE：`S11 MME GTP-C interface` 直接指名那個位址
        # 是 MME），而那種 IE 只有 adapter 讀得到。宣告這個鍵就等於在說
        # 「這不是我推的，是線路上寫的」—— 與 `reference_point` 同一個模式。
        #
        # 排在所有推論之前：**寫著的比推出來的可信。**
        for pair in msg.detail.get(NF_ROLE_HINTS_KEY, "").split(";"):
            address, _sep, role = pair.partition("=")
            if address and role:
                vote(address, role)

        # ── S1AP：程序碼決定兩方是誰，回應方向相反 ──
        if msg.protocol == "s1ap":
            code = msg.detail.get("procedure-code")
            roles = _S1AP_ROLES.get(int(code)) if code is not None else None
            if roles is not None:
                initiator_role, responder_role = roles
                is_reply = msg.detail.get("outcome", "initiating") != "initiating"
                initiator = dst_ip if is_reply else src_ip
                responder = src_ip if is_reply else dst_ip
                vote(initiator, initiator_role)
                vote(responder, responder_role)

        # ── Diameter：(Application-Id, Command-Code) 決定兩方是誰 ──
        if msg.protocol == "diameter":
            _diameter_vote(msg, vote, src_ip, dst_ip)

        if msg.protocol == "pfcp" and msg.label.startswith("Session Establishment Request"):
            vote(src_ip, "SMF")
            vote(dst_ip, "UPF")

        # ── 階梯 2：標準埠 ──
        if msg.protocol == "ngap":
            if msg.dst.port == NGAP_PORT:
                vote(dst_ip, "AMF")
            if msg.src.port == NGAP_PORT:
                vote(src_ip, "AMF")
        # S1AP **不能**照 NGAP 那樣用埠號判。實測 Open5GS 與本專案的 fixture：
        # eNB 與 MME 的 src/dst 都是 36412（與 PFCP 的 8805 同一種情況），
        # 照 dst 埠判會讓 eNB 也收到一票 MME。36412 只證明「這是 S1AP」。
        # 角色一律交給上面那條發起方向的規則。
        # PFCP **不能**用埠號判角色：8805 是 N4 兩端共用的埠（實測 Open5GS，
        # SMF 與 UPF 的 src/dst 全是 8805），與 NGAP 的 38412 只有 AMF 側在聽
        # 完全不同。照 dst 埠判會讓 SMF 同時收到 SMF 與 UPF 兩票而互相抵銷，
        # 結果是兩個網元都退回顯示 IP。8805 只證明「這是 PFCP」，
        # 不證明「這一側是 UPF」—— 角色一律交給上面那條發起方向的規則。

        # ── 階梯 3：SBI 服務名與 User-Agent ──
        if msg.protocol == "sbi":
            service = msg.detail.get("service")
            if service and service in SBI_SERVICE_TO_NF:
                # 請求打向誰，誰就是那個服務的提供者 —— **除非那是轉送者**，
                # 那時服務名描述的是它後面的最終目標。`vote()` 會擋掉。
                vote(dst_ip, SBI_SERVICE_TO_NF[service])
            agent = msg.detail.get("user-agent")
            if agent:
                nf_type = agent.split("-")[0].split("/")[0].strip().upper()
                if nf_type in set(SBI_SERVICE_TO_NF.values()):
                    # 轉送出來的請求會保留**原始發送端**的 User-Agent
                    # （實測：`SCP → NRF` 帶著 `user-agent: SMF`），
                    # 照收會把 SMF 這一票投在 SCP 身上。`vote()` 會擋掉。
                    vote(src_ip, nf_type)

    # 只採納沒有矛盾的判定。同一個 IP 收到兩種角色代表推論鏈有問題，
    # 這時寧可不標 —— 標錯比不標更糟。
    resolved: dict[str, str] = dict(relays)
    for ip, candidates in votes.items():
        if len(candidates) == 1:
            resolved[ip] = next(iter(candidates))
    return resolved


def apply_roles(messages: list[Message], *, nas_from_ue: bool = True) -> list[Message]:
    """把判定出的角色寫回訊息端點。

    `nas_from_ue` 開啟時，NAS 訊息會改畫成 UE ↔ AMF：NAS 本來就是
    UE 與 AMF 之間的協定，gNB 只是透明轉送。照封包畫會把它擠在
    gNB↔AMF 那一段，與工程師心中的呼叫流程對不起來。
    """
    roles = resolve_roles(messages)

    for msg in messages:
        msg.src = msg.src.with_role(roles.get(msg.src.ip))
        msg.dst = msg.dst.with_role(roles.get(msg.dst.ip))

        if nas_from_ue and msg.protocol == "nas-5gs":
            # gNB 那一側換成 UE。判不出 gNB 是誰就維持原樣，不硬改。
            if msg.src.role == "gNB":
                msg.src = Endpoint(ip=msg.src.ip, port=msg.src.port, role=UE_ROLE)
            elif msg.dst.role == "gNB":
                msg.dst = Endpoint(ip=msg.dst.ip, port=msg.dst.port, role=UE_ROLE)

    return messages


#: Diameter 的角色階梯：**(Application-Id, Command-Code) → (發起方, 回應方)**。
#:
#: 判準與上面 NGAP 那條完全相同 —— 「只有某一方會發起這個程序」。差別在
#: Diameter 必須連 Application-Id 一起看：同一個命令碼在不同介面上是不同的
#: 兩方（272 在 Gx 上是 PCEF↔PCRF，在 Gy 上是 CTF↔OCS），而 258 在 Gx 上是
#: PCRF 主動發起、在別的介面上未必。
#:
#: **只收有把握的那三個介面**（2026-08-23 的裁定）。不在表上的
#: Application-Id 一律不投票 —— 圖上顯示 IP，那是誠實的「推不出來」。
#:
#: 命令碼與方向取自各介面規範的程序定義（TS 29.272 §5、TS 29.229 §6、
#: TS 29.212 §4），**只用「誰發起」這一個事實**，不引用任何條號。
DIAMETER_ROLES: dict[tuple[int, int], tuple[str, str]] = {
    # ── S6a/S6d（App 16777251）──
    (16777251, 316): ("MME", "HSS"),   # Update-Location
    (16777251, 318): ("MME", "HSS"),   # Authentication-Information
    (16777251, 321): ("MME", "HSS"),   # Purge-UE
    (16777251, 323): ("MME", "HSS"),   # Notify
    (16777251, 317): ("HSS", "MME"),   # Cancel-Location —— HSS 主動
    (16777251, 319): ("HSS", "MME"),   # Insert-Subscriber-Data
    (16777251, 320): ("HSS", "MME"),   # Delete-Subscriber-Data
    (16777251, 322): ("HSS", "MME"),   # Reset
    # ── Cx/Dx（App 16777216）—— I-CSCF 與 S-CSCF 發起的命令不同，這是
    #    這張表最有價值的地方：光看位址分不出兩台 CSCF 誰是誰。
    (16777216, 300): ("I-CSCF", "HSS"),   # User-Authorization
    (16777216, 302): ("I-CSCF", "HSS"),   # Location-Info
    (16777216, 301): ("S-CSCF", "HSS"),   # Server-Assignment
    (16777216, 303): ("S-CSCF", "HSS"),   # Multimedia-Auth
    (16777216, 304): ("HSS", "S-CSCF"),   # Registration-Termination
    (16777216, 305): ("HSS", "S-CSCF"),   # Push-Profile
    # ── Gx（App 16777238）──
    (16777238, 272): ("PCEF", "PCRF"),   # Credit-Control
    (16777238, 258): ("PCRF", "PCEF"),   # Re-Auth —— PCRF 主動
}

#: 時序圖上網元由左到右的慣用順序。不在表內的排最後，
#: 依首次出現順序。這只是呈現偏好，不影響任何判定。
PARTICIPANT_ORDER = (
    # 5G 核網（既有順序不動）
    "UE", "gNB", "AMF", "SCP", "AUSF", "UDM", "UDR", "PCF", "BSF", "NSSF",
    "NRF", "SMF", "UPF", "CHF", "SMSF", "NEF",
    # 4G EPC 控制面（T3，2026-08-23）。`MME` 原本在下面 Diameter 那組，
    # 移上來與 `eNB` 相鄰 —— 它在 S1-MME 上是接取側的對端，在 S6a 上才是
    # HSS 的對端，而**一份混合擷取檔裡兩種都會出現**；跟著接取側排，
    # UE → eNB → MME → SGW → PGW 才讀得下去。
    "eNB", "MME", "SGW", "PGW",
    # Diameter：中繼 → IMS → 訂戶資料 → 策略（2026-08-23）
    # IMS：接取側的 P-CSCF 排在兩個查詢用的 CSCF 之前（訊令的實際順序）。
    "DRA", "P-CSCF", "I-CSCF", "S-CSCF", "HSS", "PCEF", "PCRF",
)


def participant_rank(endpoint: Endpoint) -> tuple[int, str]:
    role = endpoint.role
    if role and role in PARTICIPANT_ORDER:
        return PARTICIPANT_ORDER.index(role), ""
    return len(PARTICIPANT_ORDER), endpoint.label()
