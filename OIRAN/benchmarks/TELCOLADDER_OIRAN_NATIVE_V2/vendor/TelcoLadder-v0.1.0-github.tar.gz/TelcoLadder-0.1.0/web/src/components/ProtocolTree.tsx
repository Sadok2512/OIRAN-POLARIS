"use client";

import { useEffect, useState } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ProtocolNode } from "@/lib/types";

// Shared recursive decode-tree renderer — used by both the Session Analysis
// Decode Inspector and the Data Mining Packet Details pane, since a packet
// only carries one decode tree regardless of which mode is looking at it.
export function ProtocolTree({
  nodes,
  selectedId,
  onSelect,
  depth = 0,
}: {
  nodes: ProtocolNode[];
  selectedId?: string | null;
  onSelect?: (node: ProtocolNode) => void;
  depth?: number;
}) {
  return (
    <div className="font-mono text-xs">
      {nodes.map((node) => (
        <ProtocolTreeNode key={node.id} node={node} selectedId={selectedId} onSelect={onSelect} depth={depth} />
      ))}
    </div>
  );
}

function ProtocolTreeNode({
  node,
  selectedId,
  onSelect,
  depth,
}: {
  node: ProtocolNode;
  selectedId?: string | null;
  onSelect?: (node: ProtocolNode) => void;
  depth: number;
}) {
  // **預設全部收合**，比照 Wireshark。真實封包的解碼樹動輒上百個節點，
  // 展開兩層就會把整個面板灌滿，使用者得先捲過一堆 Frame/IP/TCP 的細節
  // 才看得到他真正要的那一層。
  //
  // 唯一的例外是 `selectedId` 的祖先鏈 —— 那是「自動聚焦到 Cause IE」
  // 那個功能，收合它等於把功能關掉。
  const [open, setOpen] = useState(!!selectedId && nodeContainsId(node, selectedId));

  // 選中的節點換了（例如點了另一則失敗事件），祖先鏈要重新展開。
  // 少了這段，第二次點的那一格會停在收合狀態而看不出原因。
  useEffect(() => {
    if (selectedId && nodeContainsId(node, selectedId)) setOpen(true);
  }, [selectedId, node]);
  const hasChildren = !!node.children?.length;
  const isSelected = node.id === selectedId;

  return (
    <div>
      <div
        className={cn(
          "flex cursor-pointer gap-1.5 rounded py-0.5 pr-1 transition-colors hover:bg-surface-hover",
          // 未選中：單行，可掃。選中：整列攤開，值再長也讀得完。
          // Wireshark 用水平捲軸解決這件事；這裡的樹在一個窄欄裡，
          // 捲軸會讓人捲丟位置，所以改成「只有你正在看的那一列會變高」。
          isSelected ? "items-start bg-signal-cyan-bg text-fg font-medium" : "items-center",
        )}
        style={{ paddingLeft: depth * 14 }}
        onClick={() => {
          onSelect?.(node);
          if (hasChildren) setOpen((o) => !o);
        }}
      >
        {hasChildren ? (
          open ? (
            <ChevronDown className="h-3 w-3 shrink-0 text-fg-dim" />
          ) : (
            <ChevronRight className="h-3 w-3 shrink-0 text-fg-dim" />
          )
        ) : (
          <span className="inline-block h-3 w-3 shrink-0" />
        )}
        <span className={cn("text-signal-cyan font-mono", !isSelected && "truncate")}>{node.label}</span>
        {node.detail && (
          <span
            className={cn(
              "text-fg-muted font-mono",
              // 選中時 `break-all` 而不是 `break-words`：這些值是 JSON 與
              // 十六進位，沒有空白可以斷，`break-words` 會讓它整條溢出。
              isSelected ? "break-all" : "truncate",
            )}
          >
            {node.detail}
          </span>
        )}
      </div>
      {hasChildren && open && (
        <div>
          {node.children!.map((child) => (
            <ProtocolTreeNode key={child.id} node={child} selectedId={selectedId} onSelect={onSelect} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

function nodeContainsId(node: ProtocolNode, id: string): boolean {
  if (node.id === id) return true;
  return node.children?.some((child) => nodeContainsId(child, id)) ?? false;
}
